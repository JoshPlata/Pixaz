import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prod-emp',
  templateUrl: './prod-emp.component.html',
  styleUrls: ['./prod-emp.component.css']
})
export class ProdEmpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
