import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-direccion-cliente',
  templateUrl: './direccion-cliente.component.html',
  styleUrls: ['./direccion-cliente.component.css']
})
export class DireccionClienteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
