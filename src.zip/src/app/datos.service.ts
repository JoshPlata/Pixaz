import { useAnimation } from '@angular/animations';
import { Injectable } from '@angular/core';
import { Usuarios } from './data/usuario-data';
import { Usuario } from './model/Usuario';

@Injectable({
  providedIn: 'root'
})
export class DatosService {

  usuarioschidos: Usuario[];
  constructor() {
    this.usuarioschidos=[];
   }

  getUsuarios():Usuario[]{
    return Usuarios;
  }
  setUsuario(usuario: Usuario):void{
    this.usuarioschidos.push(usuario);
  }

  getUsuarioval(id: string):string{    
    let chale= this.usuarioschidos.find( value => value.correo===id).tipo;    
    return chale;
  }
}

