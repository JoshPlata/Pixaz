import { useAnimation } from '@angular/animations';
import { Injectable } from '@angular/core';
import { PedidoData } from './data/pedido-data';
import { ProductoData } from './data/producto-data';
import { Usuarios } from './data/usuario-data';
import { Pedido } from './model/Pedido';
import { Producto } from './model/Producto';
import { Usuario } from './model/Usuario';

@Injectable({
  providedIn: 'root'
})
export class DatosService {

  usuarioschidos: Usuario[];
  productoschidos: Producto[];
  pedidoschidos: Pedido[];

  constructor() {
    this.usuarioschidos=Usuarios;
    this.productoschidos=ProductoData;
    this.pedidoschidos=PedidoData;
   }

    getUsuarios():Usuario[]{
      return this.usuarioschidos;
    }

    getProductos():Producto[]{
      return this.productoschidos;
    }

    getPedidos():Pedido[]{
      return this.pedidoschidos;
    }

    setUsuario(usuario: Usuario):void{
      this.usuarioschidos.push(usuario);
    }
    setProducto(usuario: Producto):void{
      this.productoschidos.push(usuario);
    }
    setPedido(usuario: Pedido):void{
      this.pedidoschidos.push(usuario);
    }

    getUsuarioval(id: string):string{    
      let chale= this.usuarioschidos.find( value => value.correo===id).tipo;    
      return chale;
    }
}

