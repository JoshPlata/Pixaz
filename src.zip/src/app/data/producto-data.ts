import { Producto } from '../model/Producto';
export const ProductoData:Producto[]=[
    {
        id_producto:1,
        nombre:"coca cola",
        precio:15,
        tipo:" Bebidas",
        descripcion:"1L"
    },
    {
        id_producto:2,
        nombre:"Fanta",
        precio:15,
        tipo:"Bebidas",
        descripcion:"2L"
    },
    {
        id_producto:3,
        nombre:"Pepsi",
        precio:16,
        tipo:"Bebidas",
        descripcion:"2L"
    },
    {
        id_producto:4,
        nombre:"Fresca",
        precio:14,
        tipo:"Bebidas",
        descripcion:"1L"
    },
    {
        id_producto:5,
        nombre:"Dr Peper",
        precio:10,
        tipo:"Bebidas",
        descripcion:"500ML"
    },
    {
        id_producto:6,
        nombre:"pizza",
        precio:70,
        tipo:"Alimentos",
        descripcion:"pizza grande 3 quesos"
    },
    {
        id_producto:7,
        nombre:"Alitas",
        precio:50,
        tipo:"Alimentos",
        descripcion:"8 Alitas BBQ"
    },
    {
        id_producto:8,
        nombre:"Papas",
        precio:25,
        tipo:"Alimentos",
        descripcion:"papas a la francesa con queso"
    },
    {
        id_producto:9,
        nombre:"Hamburgesas",
        precio:80,
        tipo:"Alimentos",
        descripcion:"hamburgesa a la Haeaiana"
    },
    {
        id_producto:10,
        nombre:"boneless",
        precio:70,
        tipo:"Alimentos",
        descripcion:"BBQ"
    },

]