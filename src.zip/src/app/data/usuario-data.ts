import {Usuario} from '../model/Usuario'
export let Usuarios: Usuario[]=[
    {
        id_usuario:1,
        nombre:"Lalito ",
        correo:"lalito@gmail.com",
        telefono:5512345,
        direccion:"las milpas 3",
        tipo:"cliente",
    },
    {
        id_usuario:2,
        nombre:"plata",
        correo:"plata@gmail.com",
        telefono:553344335,
        direccion:"los rosales izquierdos",
        tipo:"trabajador",
    },
    {
        id_usuario:3,
        nombre:"Jair",
        correo:"jair@gmail.com",
        telefono:5534545,
        direccion:"izalli cofra 3",
        tipo:"cliente",
    }   
]