import { Pedido } from '../model/Pedido';
export const PedidoData:Pedido[]=[
    
    {
        ListaProductos:[{
            id_producto:1,
            nombre:"coca cola",
            precio:15,
            tipo:" Bebidas",
            descripcion:"1L"
        }],
        folio:1234,
        estatus:1,
        id_cliente_Pedido:1,
        precio:300
    },
]