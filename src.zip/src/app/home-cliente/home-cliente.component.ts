import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-home-cliente',
  templateUrl: './home-cliente.component.html',
  styleUrls: ['./home-cliente.component.css']
})
export class HomeClienteComponent implements OnInit {

  constructor(private route:ActivatedRoute) { }
  cliente: string;
  folio:string;
  ngOnInit(): void {
    this.empazando();
  }

  empazando(){
    const name: string=this.route.snapshot.paramMap.get('name');    
    this.cliente=name;
  }
}
