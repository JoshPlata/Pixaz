import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pedido-cliente',
  templateUrl: './pedido-cliente.component.html',
  styleUrls: ['./pedido-cliente.component.css']
})
export class PedidoClienteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
