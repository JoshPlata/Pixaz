import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-pedido-cliente',
  templateUrl: './pedido-cliente.component.html',
  styleUrls: ['./pedido-cliente.component.css']
})
export class PedidoClienteComponent implements OnInit {

  constructor(private route:ActivatedRoute) { }

  folio:string;
  ngOnInit(): void {
    this.empazando();
  }

  empazando(){
    const name: string=this.route.snapshot.paramMap.get('name');    
    this.folio=name;
  }

}
