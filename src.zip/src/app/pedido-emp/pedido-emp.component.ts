import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pedido-emp',
  templateUrl: './pedido-emp.component.html',
  styleUrls: ['./pedido-emp.component.css']
})
export class PedidoEmpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
