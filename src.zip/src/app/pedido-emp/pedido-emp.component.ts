import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { DatosService } from '../datos.service';
import { Pedido } from '../model/Pedido';


@Component({
  selector: 'app-pedido-emp',
  templateUrl: './pedido-emp.component.html',
  styleUrls: ['./pedido-emp.component.css']
})
export class PedidoEmpComponent implements OnInit {

  pedidos: Pedido[];

  constructor(private pedidoService: DatosService) { }

  ngOnInit(): void {
    this.setPedidos();
  }

  setPedidos(): void {
    this.pedidos = this.pedidoService.getPedidos();
  }

}
