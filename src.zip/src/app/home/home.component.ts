import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatosService } from '../datos.service';
import { Usuario } from '../model/Usuario';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  form: FormGroup;
  form2: FormGroup;
  usuarios: Usuario[] = [];

  constructor(private fb: FormBuilder,
    private dato: DatosService,
    private route: Router) { }

  ngOnInit(): void {
    this.Formulario();
    this.usuarios = this.dato.getUsuarios();
  }

  private Formulario() {
    this.form = this.fb.group({
      correo: ['', [Validators.required]],
      contra: ['', [Validators.required]],

    });
    this.form2 = this.fb.group({
      correo: ['', [Validators.required]],
      nombre: ['', [Validators.required]],
      telefono: ['', [Validators.required]],
      tipo: ['', [Validators.required]],
    });
  }

  log(eve: Event) {
    eve.preventDefault();
    console.log('Logeado');
    let chido = this.dato.getUsuarioval(this.logField);
    console.log(chido);
    if (chido === 'cliente') {
      this.route.navigate(['/homecliente/',this.correoField]);
    }
    if (chido === 'empleado') {
      this.route.navigate(['/homeempleado']);
    }    
  }

  save(eve: Event) {
    eve.preventDefault();
    console.log(this.form2.value);

    this.dato.setUsuario(new Usuario({

      id_usuario: 1,
      nombre: this.nombreField,
      correo: this.correoField,
      telefono: this.telefonoField,
      direccion: '',
      tipo: this.tipoField

    }));
    console.log('Guardado');

  }
  get logField(): string {
    return this.form.get("correo").value;
  }
  get contraField() {
    return this.form.get("contra").value;
  }
  get correoField() {
    return this.form2.get("correo").value;
  }
  get nombreField() {
    return this.form2.get("nombre").value;
  }
  get telefonoField() {
    return this.form2.get("telefono").value;
  }
  get tipoField() {
    return this.form2.get("tipo").value;
  }
}
