import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-emp',
  templateUrl: './home-emp.component.html',
  styleUrls: ['./home-emp.component.css']
})
export class HomeEmpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
