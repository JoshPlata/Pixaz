import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DatosService } from '../datos.service';

@Component({
  selector: 'app-hacer-cliente',
  templateUrl: './hacer-cliente.component.html',
  styleUrls: ['./hacer-cliente.component.css']
})
export class HacerClienteComponent implements OnInit {

  form: FormGroup;
  constructor(private route:ActivatedRoute,
              private dato: DatosService,
              private fb: FormBuilder) { }

  cliente:string;
  ngOnInit(): void {
    this.empazando();
  }
  

  empazando(){
    const name: string=this.route.snapshot.paramMap.get('name');    
    this.cliente=name;
  }
}
