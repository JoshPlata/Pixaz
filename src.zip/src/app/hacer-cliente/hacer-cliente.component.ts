import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hacer-cliente',
  templateUrl: './hacer-cliente.component.html',
  styleUrls: ['./hacer-cliente.component.css']
})
export class HacerClienteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
