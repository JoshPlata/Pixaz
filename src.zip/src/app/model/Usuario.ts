export class Usuario{
    id_usuario:number;
    nombre:string;
    correo:string;
    telefono:number;
    direccion:string;
    tipo:string;
    constructor(values: Object={}){
        Object.assign(this,values);
    }
}