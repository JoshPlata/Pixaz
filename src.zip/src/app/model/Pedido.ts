import { Producto } from './Producto';

export class Pedido{
    ListaProductos:Producto[];
    folio:number;
    estatus:number;
    id_cliente_Pedido:number;
    precio:number;

    constructor(values: Object={}){
        Object.assign(this,values);
    }
}