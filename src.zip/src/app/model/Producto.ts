export class Pedido{
    
}